const express = require("express");
const router = express.Router();

const {getAllProducts, getAllProductsReference, getAllProductsLogin, getAllProductsPhone} = require("../controllers/index")

router.route("/").get(getAllProducts);
router.route("/reference").get(getAllProductsReference);
router.route("/login").get(getAllProductsLogin);
router.route("/phone").get(getAllProductsPhone);
module.exports = router;