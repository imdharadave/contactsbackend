const mysql= require('mysql');
const con= mysql.createConnection({
    host:"localhost",
    user: "root",
    password:"Y@1712ydsd#",
    database:"admitdb"
});
const getAllProducts = async(req, res) => {
    con.query("select * from contactform", function(err, result){
        if(err) res.status(400).json({msg:err});
        res.status(200).json({ data:result});
    })
};

const getAllProductsReference = async(req, res) => {
    con.query("select * from  reference", function(err, result){
        if(err)res.status(200).json({msg:err});
        res.status(200).json({data:result});
    })
    
};
const getAllProductsLogin = async(req, res) => {
    con.query("select * from  login", function(err, result){
        if(err)res.status(200).json({msg:err});
        res.status(200).json({data:result});
    })
};

const getAllProductsPhone = async(req, res) => {
    con.query("select * from  phoneno", function(err, result){
        if(err)res.status(200).json({msg:err});
        res.status(200).json({data:result});
    })
};
module.exports = {getAllProducts, getAllProductsReference, getAllProductsLogin, getAllProductsPhone };