
const mysql= require('mysql');
const con= mysql.createConnection({
    host:"localhost",
    user: "root",
    password:"Y@1712ydsd#",
    database:"admitdb"
});
con.connect(function(error){
        if(error) throw error;
        con.query("select * from contactform", function(err, result){
            if(err) throw err;
            console.warn("all results are here",result);
        })
     
    })
